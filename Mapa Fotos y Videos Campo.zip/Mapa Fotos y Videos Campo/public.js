document.addEventListener('DOMContentLoaded', () => {

    fetch('/data')
        .then(response => response.json())
        .then(data => {
            L.geoJSON(data).addTo(map);
        })
        .catch(err => console.error('Error al cargar los datos:', err));
});