var mapa = L.map("contenedor-mapa").setView([-12.029017360904646, -77.08493439310774],11);
L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png?",{}).addTo(mapa);

var mediaDisplay = document.getElementById('media-display');
var closeButton = document.getElementById('close-media-display');


// Fetch the media data file
fetch('/Videos/gps_data.txt') // 'http://localhost:8081/gps_data.txt'
    .then(response => response.text())
    .then(data => {
        // Process the data
        var mediaItems = data.trim().split("\n").map(function(line) {
            var parts = line.split(",");
            return {
                filename: parts[0].trim(),
                lat: parseFloat(parts[1]),
                lon: parseFloat(parts[2])
            };
        });

        // Add markers to the map
        mediaItems.forEach(function(item) {
            var marker = L.marker([item.lat, item.lon]).addTo(mapa);
            marker.on('click', function() {
                displayMedia(item.filename);
            });
        });
    })
    .catch(error => console.error('Error fetching media data:', error));

function displayMedia(filename) {
    mediaDisplay.innerHTML = '<button id="close-media-display">x</button>';
    mediaDisplay.style.display = 'block';

    if (filename.endsWith(".png") || filename.endsWith(".jpg")) {
      var img = document.createElement('img');
      img.src = '/Videos/' + filename; // 'http://localhost:8081/'
      img.onload = function() {
          mediaDisplay.style.display = 'block';
      };
      img.onerror = function() {
          console.error('Error loading image:', img.src);
      };
      mediaDisplay.appendChild(img);
  } else if (filename.endsWith(".mp4") || filename.endsWith(".MOV")) {
      var video = document.createElement('video');
      video.src = '/Videos/' + filename; //  'http://localhost:8081/'
      video.controls = true;
      video.onloadeddata = function() {
          mediaDisplay.style.display = 'block';
      };
      video.onerror = function() {
          console.error('Error loading video:', video.src);
      };
      mediaDisplay.appendChild(video);
  } else if (filename.endsWith(".HEIC")) {
      fetch('/Videos/' + filename) // 'http://localhost:8081/'
          .then(response => response.blob())
          .then(blob => heic2any({
              blob: blob,
              toType: "image/jpeg"
          }))
          .then(conversionResult => {
              var img = document.createElement('img');
              img.src = URL.createObjectURL(conversionResult);
              img.onload = function() {
                  mediaDisplay.style.display = 'block';
              };
              img.onerror = function() {
                  console.error('Error loading converted HEIC image:', img.src);
              };
              mediaDisplay.appendChild(img);
          })
          .catch(error => console.error('Error converting HEIC image:', error));
  } else {
      console.error('Unsupported media type:', filename);
  }
    // Re-attach event listeners to the newly created buttons
    document.getElementById('close-media-display').addEventListener('click', function() {
        mediaDisplay.style.display = 'none';
        mediaDisplay.innerHTML = '';
    });
}

// Close button functionality
closeButton.addEventListener('click', function() {
    mediaDisplay.style.display = 'none';
    mediaDisplay.innerHTML = '';
});

// Initialize the geocoder and add it to the map
var geocoder = L.Control.geocoder({
    position: 'topright',
    defaultMarkGeocode: false,
    collapsed: false,
    placeholder: "",
    errorMessage: ""
}).on('markgeocode', function(e) {
    var bbox = e.geocode.bbox;
    var poly = L.polygon([
        bbox.getSouthEast(),
        bbox.getNorthEast(),
        bbox.getNorthWest(),
        bbox.getSouthWest()
    ]);
    mapa.fitBounds(poly.getBounds());
}).addTo(mapa);

// Function to hide geocoder results when clicking outside
function hideGeocoderResults(e) {
    var target = e.target;
    var geocoderElement = document.querySelector('.leaflet-control-geocoder');
    if (geocoderElement && !geocoderElement.contains(target)) {
        var results = document.querySelector('.leaflet-control-geocoder-alternatives');
        if (results) {
            results.style.display = 'none';
        }
    }
}

document.addEventListener('click', hideGeocoderResults);

// Show geocoder results again when focusing the input
var geocoderInput = document.querySelector('.leaflet-control-geocoder-form input');
geocoderInput.addEventListener('focus', function() {
    var results = document.querySelector('.leaflet-control-geocoder-alternatives');
    if (results) {
        results.style.display = 'block';
    }
});

