const express = require('express');
const { Pool } = require('pg');

const app = express();
const pool = new Pool({
    user: 'jeisont_ic',
    host: '45.55.196.81',
    database: 'icinre_server',
    password: 'InreIC2023',
    port: 5432,
});

app.use(express.static('public'));

app.get('/data', async (req, res) => {
    try {
        const queryResult = await pool.query('SELECT ST_AsGeoJSON(geom) AS geojson FROM mass.tiendas_mass');
        const geojson = {
            type: 'FeatureCollection',
            features: queryResult.rows.map(row => JSON.parse(row.geojson))
        };
        res.json(geojson);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en el puerto ${PORT}`);
});